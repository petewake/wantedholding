$(document).ready(function() {

	function fullWindow() {
		$(".fullwindow").css("height", $(window).height());
	};
	fullWindow();
	$(window).resize(function() {
		fullWindow();
	});

	$('.scroll-but').on('click', function (event) {
		event.preventDefault();
		var link = $(this).attr('data-link');
		$('html, body').animate({
		    scrollTop: $('#'+link).offset().top
		}, 1000);
	});

	$(".close-menu").click(function() {
		$(".menu-overlay").fadeOut(500);
	});
	
	$(".menu-triger-wrap").click(function() {
			$(".menu-overlay").fadeIn(500);
	});

	$("#sticker").sticky({topSpacing:0});


});